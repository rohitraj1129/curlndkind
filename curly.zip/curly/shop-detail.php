<!DOCTYPE html>
<html class="no-js">
<head>
	<?php include('includes/head.php');?>
	<?php include('include/config.php');?>  
	<script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.min.js"></script>
    </head>

<body>
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<?php include('includes/header.php');?>


			<section class="page_breadcrumbs ds parallax section_padding_top_50 section_padding_bottom_50" style="background-position: 50% -1px;">
            <img src="images/1555399120slide-inner.jpg">
            </section>

            
            <?php
if (isset($_GET['id']))

               {

            $id=$_GET['id'];

            $sid= base64_decode($id);
}
     ?>
     
    
      <?php		
            $ids=$_GET['id'];
        $id=base64_decode($ids);
	$sql= "SELECT * FROM curly_shop_details where cat_id='$id'";
	$qry= mysqli_query($obj,$sql);
	$data= mysqli_fetch_array($qry);                           
     ?>
			
            
			<div class="using-border">
              <ol class="breadcrumb darklinks">
								<li><a href="./">Home</a>
								<li><a href="shop.php">Shop</a>
								</li><li class="active"><?php echo $data['title'];?></li>
							</ol>
		</div>

			<section class="ls section_padding_top_100 section_padding_bottom_100 columns_padding_25">
				<div class="container">
                    
        <?php
        $ids=$_GET['id'];
        $id=base64_decode($ids);
        $query="select * from curly_shop_details where status=1 and cat_id='$id'";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>              
                    
					<div class="row">
<form class="cart" method="post" enctype="multipart/form-data">
						<div class="col-sm-12">
                  

							<div itemscope="" itemtype="http://schema.org/Product" class="product type-product row columns_padding_25">

								<div class="col-sm-6">
									
								<div class="product-details-large" id="ProductPhoto">
                                    <img id="ProductPhotoImg" class="product-zoom" data-image-id="" alt="12. Aliexpress dropshipping by oberlo" data-zoom-image="images/<?php echo $data['image']; ?>" src="images/<?php echo $data['image']; ?>">
          
                                </div>
            
                                    
                                    
                                <div id="ProductThumbs" class="product-thumbnail owl-carousel">
                                    
                                   
                                    
                                    <!--<a class="product-single__thumbnail active" href="images/<?php echo $data['image']; ?>" data-image="images/<?php echo $data['image']; ?>" data-zoom-image="images/<?php echo $data['image']; ?>" data-image-id="6995357106246">
                                    <img src="images/<?php echo $data['image']; ?>" alt="12. Aliexpress dropshipping by oberlo"></a>-->
                                    
                                    
          
                                    <a class="product-single__thumbnail " href="shop/hatbig2.jpg" 
                                    data-image="shop/hatbig2.jpg" data-zoom-image="shop/hatbig2.jpg" data-image-id="6995358023750">
                                    <img src="shop/hatbig2.jpg" alt="12. Aliexpress dropshipping by oberlo"></a>
          
                                    <a class="product-single__thumbnail " href="shop/hatbig3.jpg" 
                                    data-image="shop/hatbig3.jpg" data-zoom-image="shop/hatbig3.jpg" data-image-id="6995357302854">
                                    <img src="shop/hatbig3.jpg" alt="12. Aliexpress dropshipping by oberlo"></a>
          
                                    <a class="product-single__thumbnail " href="shop/hatbig4.jpg" 
                                    data-image="shop/hatbig4.jpg" data-zoom-image="shop/hatbig4.jpg" data-image-id="6995357532230">
                                    <img src="shop/hatbig4.jpg" alt="12. Aliexpress dropshipping by oberlo"></a>
          
                                    <a class="product-single__thumbnail " href="shop/hatbig5.jpg" 
                                    data-image="shop/hatbig5.jpg" data-zoom-image="shop/hatbig5.jpg" data-image-id="6995357728838">
                                    <img src="shop/hatbig5.jpg" alt="12. Aliexpress dropshipping by oberlo"></a>
          
                                </div>
                            <!-- eof .images -->
								</div>

								<div class="summary entry-summary col-sm-6">
								
								<h1 itemprop="name" class="product_title"><?php echo $data['title']; ?></h1>

									<div class="content-justify vertical-center">
									<div class="product-rating bottommargin_10" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                                         SKU: <?php echo $data['sku']; ?>
										</div>
										
										<span class="price bottommargin_10">
											<span class="amount"><?php echo $data['price']; ?></span>
										</span>
										</div>


									


									<div>
										<?php echo $data['description']; ?>
										</div>

									

									<hr class="divider_30">

									

									<div class="row">
											<div class="col-sm-6">
												<h4>Choose Hat Colour</h4>
                                        <input type="hidden" name="name" value="<?php echo $data['title']; ?>">
                                        <input type="hidden" name="sku" value="<?php echo $data['sku']; ?>">
                                        <input type="hidden" name="price" value="<?php echo $data['price']; ?>">
                                        <input type="hidden" name="image" value="images/<?php echo $data['image']; ?>">
												<div class="form-group select-group">
													<select id="category" name="hat_color" class="choice form-control">
													<option value="" disabled="" selected="" data-default="">Choose</option>
														<option value="Black">Black</option>
														<option value="Grey">Grey</option>
														</select>
													<i class="fa fa-angle-down theme_button no-bg-button" aria-hidden="true"></i>
												</div>
											</div>
											<div class="col-sm-6">
												<h4>Choose Pom Pom Colour</h4>

												<div class="form-group select-group">
													<select id="size" name="pom_colour" class="choice form-control">
													<option value="" disabled="" selected="" data-default="">Choose</option>
														<option value="Red">Red</option>
														<option value="Blue">Blue</option>
														<option value="Yellow">Yellow</option>
														<option value="Pink">Pink</option>
														<option value="Green">Green</option>
														<option value="Orange">Orange</option>
														<option value="Mixed Pastel">Mixed Pastel</option>
														<option value="Bright Multicolour">Bright Multicolour</option>
													</select>
													<i class="fa fa-angle-down theme_button no-bg-button" aria-hidden="true"></i>
												</div>
											</div>
										</div>
									
									<span class="quantity form-group rightmargin_10">
											<input type="button" value="+" class="plus">
											<i class="fa fa-angle-up" aria-hidden="true"></i>
											<input type="number" step="1" min="0" name="product_quantity" value="1" title="Qty" id="product_quantity" class="form-control ">
											<input type="button" value="-" class="minus">
											<i class="fa fa-angle-down" aria-hidden="true"></i>
										</span>
<!-- <a href="javascript:void(0);" rel="nofollow" class="theme_button color2 wide_button add_to_cart_button" onClick="javascript: addToCart(<?php //echo $data['id']; ?>)">Add to cart</a> -->

                                      <input type="submit" name="addToCart" class="theme_button color2 wide_button add_to_cart_button" value="Add to cart">

									
									
									</div>
								<!-- .summary.col- -->
								
								</div></form>
							<!-- .product.row -->
                       <div class="col-xs-12 ">
                  <div class="tabs">
  <div class="tab-button-outer">
    <ul id="tab-button">
      <li><a href="#tab01">Product Info</a></li>
      <li><a href="#tab02">Return & Refund Policy</a></li>
      <li><a href="#tab03">Shipping Info</a></li>
      </ul>
  </div>
  

  <div id="tab01" class="tab-contents">
   <?php echo $data['product']; ?>
  </div>
                      
  <div id="tab02" class="tab-contents">
    <?php echo $data['policy']; ?>
                      </div>      
      
  <div id="tab03" class="tab-contents">
    <?php echo $data['shipping']; ?>
  </div>
  
                
                </div>

						</div>
						

					</div>
                  
                    
                    </div>  <?php } ?>
                </div>
			</section>
		
                                                
                <script>$(document).ready(function() {$('.fancybox').fancybox();});</script>
                <script>function productZoom(){
                        $(".product-zoom").elevateZoom({
                          gallery: 'ProductThumbs',
                          galleryActiveClass: "active",
                          zoomType: "inner",
                          cursor: "crosshair"
                        });$(".product-zoom").on("click", function(e) {
                          var ez = $('.product-zoom').data('elevateZoom');
                          $.fancybox(ez.getGalleryList());
                          return false;
                        });
                        
                        };
                      function productZoomDisable(){
                        if( $(window).width() < 767 ) {
                          $('.zoomContainer').remove();
                          $(".product-zoom").removeData('elevateZoom');
                          $(".product-zoom").removeData('zoomImage');
                        } else {
                          productZoom();
                        }
                      };

                      productZoomDisable();

                      $(window).resize(function() {
                        productZoomDisable();
                      });
                </script>
                <script>
                    $('.product-thumbnail').owlCarousel({
                        loop: true,
                        center: true,
                        nav: true,dots:false,
                        margin:10,
                        autoplay: false,
                        autoplayTimeout: 5000,
                        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                        item: 3,
                        responsive: {
                            0: {
                                items: 2
                            },
                            480: {
                                items: 3
                            },
                            992: {
                                items: 3,
                            },
                            1170: {
                                items: 3,
                            },
                            1200: {
                                items: 3
                            }
                        }
                    });
                </script>
            
			
			

			<?php include('includes/footer.php')?>
			
			<script>
			$(function() {
  var $tabButtonItem = $('#tab-button li'),
      $tabSelect = $('#tab-select'),
      $tabContents = $('.tab-contents'),
      activeClass = 'is-active';

  $tabButtonItem.first().addClass(activeClass);
  $tabContents.not(':first').hide();

  $tabButtonItem.find('a').on('click', function(e) {
    var target = $(this).attr('href');

    $tabButtonItem.removeClass(activeClass);
    $(this).parent().addClass(activeClass);
    $tabSelect.val(target);
    $tabContents.hide();
    $(target).show();
    e.preventDefault();
  });

  $tabSelect.on('change', function() {
    var target = $(this).val(),
        targetSelectNum = $(this).prop('selectedIndex');

    $tabButtonItem.removeClass(activeClass);
    $tabButtonItem.eq(targetSelectNum).addClass(activeClass);
    $tabContents.hide();
    $(target).show();
  });
});
			</script>

</body>
</html>


<?php 
if(isset($_POST['addToCart'])){

if(isset($_SESSION["shopping_cart"])){
	$itemarray_id = array_column($_SESSION['shopping_cart'], "item_id");
	if(!in_array($id, $itemarray_id))
	{
		$count = count($_SESSION['shopping_cart']);
		$itemarray = array(
   	                   'item_id' => $id, 
   	                   'item_name'=> $_POST['name'],
   	                   'item_image'=> $_POST['image'],
   	                   'item_sku'=> $_POST['sku'],
   	                   'item_price'=> $_POST['price'],
   	                   'item_hat_color'=> $_POST['hat_color'],
   	                   'item_pom_colour'=> $_POST['pom_colour'],
   	                   'item_qty'=> $_POST['product_quantity']

                     );
		 $_SESSION["shopping_cart"][$count] = $itemarray;
		 header("location:cart.php");
	}

	else{

		echo'<script>alert("Items already added")</script>';
		header("location:cart.php");
	}
}



else{


   $itemarray = array(
   	                   'item_id' => $id, 
   	                   'item_name'=> $_POST['name'],
   	                   'item_image'=> $_POST['image'],
   	                   'item_sku'=> $_POST['sku'],
   	                   'item_price'=> $_POST['price'],
   	                   'item_hat_color'=> $_POST['hat_color'],
   	                   'item_pom_colour'=> $_POST['pom_colour'],
   	                   'item_qty'=> $_POST['product_quantity']

                     );
              $_SESSION["shopping_cart"][0] = $itemarray;
              header("location:cart.php");

}
}
?>