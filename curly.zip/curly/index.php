<!DOCTYPE html>
<html class="no-js">

<head>
<?php include('includes/head.php');?>
<?php include('include/config.php');?>
</head>
<body>
	
	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->
             <?php include('includes/header.php');?>


			<section class="intro_section page_mainslider ds">
				<div class="flexslider vertical-nav" data-dots="true" data-nav="false">
                    
                 <?php

        $query="select * from home_banner where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?> 
			    
					<ul class="slides">

						<li>
							<img src="images/<?php echo $data['image']; ?>" alt="">
							<div class="container">
								<div class="row">
									<div class="col-sm-12 text-left">
										<div class="slide_description_wrapper">
                                           								<div class="slide_description">
												<div class="intro-layer" data-animation="fadeInUp">
												<img src="images/curly-logo-banner.png">
													<h2>
														<span class="highlight2"><?php echo $data['large']; ?></span>
													</h2>
												</div>
												<div class="intro-layer" data-animation="fadeInUp">
													<p><?php echo $data['small']; ?></p>
												</div>
												<div class="intro-layer" data-animation="fadeInUp">
													<a href="#" class="theme_button color2 two_lines_button">
											<?php echo $data['button']; ?>
										</a>
												</div>
											</div>
											<!-- eof .slide_description -->
										</div>
										<!-- eof .slide_description_wrapper -->
									</div>
									<!-- eof .col-* -->
								</div>
								<!-- eof .row -->
							</div>
							<!-- eof .container -->
						</li>
                     </ul><?php } ?>
				</div>
				<!-- eof flexslider -->

			</section>

			<!-- icon-background-teaser -->
			<section class="ls section_padding_top_50 section_padding_bottom_50 collection">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h2 class="section_header highlight">
								SHOP<span> Collection</span>
							</h2>
                            <?php

        $query="select * from home_shop where status=1 order by position ASC";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?> 
							<div class="col-sm-3">
                                
							<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/<?php echo $data['image']; ?>" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											<?php echo $data['title']; ?>
										</h4>
										<!--<div class="catogories-links highlight2links small-text medium">
											Say goodbye to frizzy hats days
										</div>-->
										<a href="<?php echo $data['link']; ?>"><?php echo $data['button_text']; ?></a>
									</div>
									</div>
									</div><?php } ?>

									
									
                             
						</div>
					</div>
				</div>
			</section>
			
			
			
			<!--<section class="ls section_padding_top_100 section_padding_bottom_100 collection">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h2 class="section_header highlight">
								# SHOP<span> Collection</span>
							</h2>
							<div class="owl-carousel topmargin_60" data-responsive-lg="3" data-nav="true">
								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/1.png" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											CURLY HATS
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Say goodbye to frizzy hats days
										</div>
										<a href="">Shop Now</a>
									</div>
									</div>

								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/2.png" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											KIND PILLOW CASES
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Satin pillow cases so you always wake up with happy hair
										</div>
										<a href="">Shop Now</a>
									</div>
									</div>

								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/ayurvedic.jpg" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											LOTIONS & POTIONS
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Organic hair edible goodies coming soon
										</div>
										<a href="">Shop Now</a>
									</div>
								</div>
								
								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/1.png" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											CURLY HATS
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Say goodbye to frizzy hats days
										</div>
										<a href="">Shop Now</a>
									</div>
									</div>
									
                              </div>
						</div>
					</div>
				</div>
			</section>-->
			
			
			

			<section class="ls section_padding_top_100 section_padding_bottom_100 columns_margin_bottom_30 columns_padding_25 table_section table_section_md">
				<div class="container">
					<div class="row">
						<div class="col-md-7 aboutbox">
                             <?php

        $query="select *from about where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?> 
							<h2 class="section_header highlight">
								<?php echo $data['large']; ?> <span><?php echo $data['small']; ?></span>
							</h2>
           
                            
							<p class="fontsize_18"><?php echo $data['description']; ?></p>
                           
							<!--<p class="topmargin_30">
					<a href="#" class="read-more">read more</a>
				</p>-->
						</div>
						
						<div class="col-md-6 about">
							<img src="images/<?php echo $data['image']; ?>" alt=""><br><br>
							<img src="images/<?php echo $data['image2']; ?>" alt="">
							</div>
						<!---<div class="col-md-2 about">
							<img src="images/home2.jpg" alt="" />
							</div>-->
						
					</div> <?php }?>
				</div>
			</section>

			

			
<section class="ls section_padding_top_100 section_padding_bottom_100 instagram">
				<div class="container-fluid">
                     <?php

        $query="select *from home_image where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>   
					<div class="row columns_padding_25 columns_margin_bottom_20">
						<div class="col-md-6">
                
                         
                            
				<img src="images/<?php echo $data['image']; ?>">

                            
           
                            
						</div>
						<div class="col-md-6 instagrambox">
							<h1 class="entry-title">
								<?php echo $data['text1']; ?>
							</h1>
							<h6><?php echo $data['text2']; ?></h6>
							<div class="insta-button text-center">
            <a href="<?php echo $data['url']; ?>" target="_blank"><span><?php echo $data['tab']; ?></span></a>
          </div>
						</div> <?php }?>
					</div>
					
				</div>
			</section>
			
			<section class="ls stats-count">

      <div class="container">
          <?php

        $query="select *from vision where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>      
	  <h2 class="section_header highlight" style="margin-bottom:0px;">
								<?php echo $data['large']; ?> <span><?php echo $data['small']; ?></span>
							</h2>
             
<div class="row text-center">
<p style="width: 100%;"><?php echo $data['description']; ?></p>
    
       <?php } ?>
          
        </div>

      </div>

    </section>
			
			<section id="newsletter" class="section-newsletter-area">
        <div class="newsletter-area section-padding">
            <div class="container">
                <div class="row">
                    <!-- start newsletter inner -->
                    <div class="inner-newsletter">
                        <div class="col-md-6 newsbox">
                            <!--start newsletter title -->
                            <div class="newsletter-title">
                                <h2 class="signup"><span>SIGN UP </span> FOR SPECIAL PROMOTIONS</h2>
                
            <?php

        $query="select *from sign_up where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>                      
                                <p><?php echo $data['description']; ?></p>
                               
                                
                <?php } ?>                
                            </div>
                            <!-- end newsletter title -->
                        </div>
                        <div class="col-md-6 newsbox">
                            <!-- start signup form -->
                            <div class="signup-form">
                                <form action="#" class="news-form">
                                    <input type="text" class="f-form" placeholder="Enter your email address...">
                                    <button class="submit text-uppercase">subscribe !</button>
                                </form>
                            </div>
                            <!--end signup form -->
                        </div>
                    </div>
                    <!-- end newsletter inner -->
                </div>
            </div>
        </div>
    </section>
			

			<?php include('includes/footer.php')?>
</body>
</html>