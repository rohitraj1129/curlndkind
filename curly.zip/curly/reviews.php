<!DOCTYPE html>
<html class="no-js">
<head>
<?php include('includes/head.php');?>
<?php include('include/config.php');?>  
</head>

<body>
	
	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<?php include('includes/header.php');?>


			<section class="page_breadcrumbs ds parallax section_padding_top_50 section_padding_bottom_50">
        <?php

        $query="select *from review_banner where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>          
			<img src="images/<?php echo $data['image']; ?>">
                
        <?php } ?>        
			</section>
			
			<div class="using-border">
              <ol class="breadcrumb darklinks">
								<li><a href="./">Home</a>
								</li><li class="active">Reviews</li>
							</ol>
		</div>
			
			
			<section class="ls section_padding_top_50 section_padding_bottom_50 collection">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
                    <?php

        $query="select *from review_text where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>         
							<h2 class="section_header highlight" style="margin-bottom: 0px;">
								<?php echo $data['description']; ?>
							</h2>
                    <?php } ?>        
                            
    	
                            
        <?php

        $query="select *from review where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>                     
            <div class="col-md-4 center-block">
             <div class="reviews-bg-clor">
			<div class="reviews-bg-pointer">
			</div>
			 <img src="images/<?php echo $data['image']; ?>" class="img-responsive">
			</div> 
            </div>
<?php } ?>			
                            
			<!--<div class="col-md-4 center-block">
             <div class="reviews-bg-clor">
			<div class="reviews-bg-pointer">
			</div>
			 <img src="images/Review2.png" class="img-responsive">
			</div>   
            </div>
			
			<div class="col-md-4 center-block">
            <div class="reviews-bg-clor">
			<div class="reviews-bg-pointer">
			</div>
			 <img src="images/review3.png" class="img-responsive">
			</div>   
            </div>
			
			<div class="col-md-4 center-block">
            <div class="reviews-bg-clor">
			<div class="reviews-bg-pointer">
			</div>
			 <img src="images/Review4.png" class="img-responsive">
			</div>   
            </div>-->
			
			
           <div> 
        </div>
						</div>
					</div>
				</div>
			</section>
			
			
			
			<!--<section class="ls section_padding_top_100 section_padding_bottom_100 collection">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h2 class="section_header highlight">
								# SHOP<span> Collection</span>
							</h2>
							<div class="owl-carousel topmargin_60" data-responsive-lg="3" data-nav="true">
								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/1.png" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											CURLY HATS
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Say goodbye to frizzy hats days
										</div>
										<a href="">Shop Now</a>
									</div>
									</div>

								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/2.png" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											KIND PILLOW CASES
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Satin pillow cases so you always wake up with happy hair
										</div>
										<a href="">Shop Now</a>
									</div>
									</div>

								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/ayurvedic.jpg" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											LOTIONS & POTIONS
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Organic hair edible goodies coming soon
										</div>
										<a href="">Shop Now</a>
									</div>
								</div>
								
								<div class="vertical-item content-padding with_border">
									<div class="item-media">
										<img src="images/1.png" alt="">
									</div>
									<div class="item-content">
										<h4 class="entry-title">
											CURLY HATS
										</h4>
										<div class="catogories-links highlight2links small-text medium">
											Say goodbye to frizzy hats days
										</div>
										<a href="">Shop Now</a>
									</div>
									</div>
									
                              </div>
						</div>
					</div>
				</div>
			</section>-->
			
			
			<section id="newsletter" class="section-newsletter-area">
        <div class="newsletter-area section-padding">
            <div class="container">
                <div class="row">
                    <!-- start newsletter inner -->
                    <div class="inner-newsletter">
                        <div class="col-md-9 newsbox">
                            <!--start newsletter title -->
                            <div class="newsletter-title">
                                <h2 class="signup"><span>HANDMADE PRODUCTS </span> FOR SPECIAL KIND TO YOUR HAIR.</h2>
                                </div>
                            <!-- end newsletter title -->
                        </div>
                        <div class="col-md-3 newsbox">
                            <!-- start signup form -->
                            <div class="signup-form">
                               <a href="shop.php" target="_blank">Shop Now!Pay Later</a>
                            </div>
                            <!--end signup form -->
                        </div>
                    </div>
                    <!-- end newsletter inner -->
                </div>
            </div>
        </div>
    </section>

			

			<?php include('includes/footer.php')?>

</body>
</html>