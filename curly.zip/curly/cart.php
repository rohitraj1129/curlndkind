<!DOCTYPE html>
<html class="no-js">
<head>
<?php include('includes/head.php');?>
<?php include('include/config.php');?>
</head>

<body>
	<?php
if(isset($_POST['coupon'])){

$coupon_code = $_POST['coupon_code'];

$sqls="select *from coupons where coupon_code='$coupon_code'";
$query= mysqli_query($obj,$sqls);
$data = mysqli_fetch_array($query);
$coupons=$data['couponpercent'];

}
 ?>
 <?php
if(isset($_POST['shipping'])){

$country = $_POST['shipping_country'];

if($country=='UK'){
	$shipping_country=$country;
	
}
elseif($country=='Row'){
	$shipping_country=$country;
	
}

else{
$select="select *from country where country='$country'";
$run=mysqli_query($obj,$select);
$data=mysqli_fetch_array($run);
$shipping_country=$data['continent'];
}
$newdata =  array (
      'country' => $shipping_country
      
    );
array_push($_SESSION['shopping_cart'],$newdata );
$query="select *from shipping where country='$shipping_country'";
$runs=mysqli_query($obj,$query);
$dataa=array();
while($datas=mysqli_fetch_assoc($runs)){
	$dataa[] = $datas;
	
    
}
echo "<pre>";
       print_r($dataa);
      
echo "<pre>";
      print_r($_SESSION['shopping_cart']);
      die(); 
}
?>


 <!--  -->
	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<?php include('includes/header.php');?>

			<section class="page_breadcrumbs ds parallax section_padding_top_50 section_padding_bottom_50">
        <?php

        $query="select *from about_banner where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>          
			<img src="images/<?php echo $data['image']; ?>">
                
        <?php } ?>        
			</section>
			
			<div class="using-border">
              <ol class="breadcrumb darklinks">
								<li><a href="./">Home</a>
								</li><li class="active">Cart</li>
							</ol>
		</div>


			<section class="ls section_padding_top_50 section_padding_bottom_50">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
                        <h2 class="section_header highlight">
								SHOP<span> Cart</span>
							</h2>
							<div class="table-responsive">
								<table class="table shop_table cart cart-table">
									<thead>
										<tr style="background-color: #000; color: #fff;">
											<td class="product-info"  style="color: #fff;">Product</td>
											<td class="product-price-td">Price</td>
											<td class="product-quantity">Quantity</td>
											<td class="product-subtotal">Subtotal</td>
											<td class="product-remove">&nbsp;</td>
										</tr>
									</thead>
									<tbody>
										<?php 
										if(!empty($_SESSION['shopping_cart'])){
	                                    $total = 0;
	                                    foreach ($_SESSION['shopping_cart'] as $key => $value) {
		             
                                         ?>

										<tr class="cart_item">
											<td class="product-info">
												<div class="media">
													<div class="media-left">
														<a href="#">
							<img class="media-object cart-product-image" src="<?php echo $value['item_image']; ?>" alt="">
														</a>
													</div>
													<div class="media-body">
														<h4 class="media-heading">
															<a href="#"><?php echo $value['item_name']; ?></a>
														</h4>
									<span class="grey">Hat Color:</span> <?php echo $value['item_hat_color']; ?>
														<br>
									<span class="grey">Pom Pom Color:</span><?php echo $value['item_pom_colour']; ?>
													</div>
												</div>
											</td>
											<td class="product-price">
												<span class="currencies">£</span>
												<span class="amount"><?php echo $value['item_price']; ?></span>
											</td>
											<td class="product-quantity">
												<div class="quantity">
													
													<input type="number" disabled="true" step="1" min="0" name="product_quantity" value="<?php echo $value['item_qty']; ?>" title="Qty" class="form-control">
													
												</div>
											</td>
											<td class="product-subtotal">
												<span class="currencies">£</span>
												<span class="amount"><?php echo number_format($value['item_qty'] * $value['item_price'], 2); ?></span>
											</td>
											<td class="product-remove">
												<a href="cart.php?action=delete&id=<?php echo $value['item_id'];?>" class="" title="Remove this item">
													<i class="fa fa-trash-o"></i>
												</a>
                                        

											</td>
										</tr>

										<?php
										$total = $total + ($value['item_qty'] * $value['item_price']);
										$discountAmount = ($total*$coupons)/100; 
					                     $newPrice = $total-$discountAmount;
					                     $totals = round($newPrice, 2); 
                                         
										?>
                                      <?php }}?>
										
									</tbody>
								</table>
							</div>

							<div class="cart-buttons">
								<a class="theme_button" href="shop.php">Countinue Shopping</a>

								<button type="submit" class="theme_button color2">Proceed to Checkout</button>
							</div>

							<div class="cart-collaterals">
								<div class="cart_totals">
									<h4>Cart Totals</h4>
									<table class="table">
										<tbody>
											<tr class="cart-subtotal">
												<td>Cart Subtotal</td>
												<td>
													<span class="currencies">£</span>
													<span class="amount"><?php echo $total ;?></span>
												</td>
											</tr>
											
											<?
                                            if ($coupons) {?>
                                            	<tr class="order-total">
												<td class="grey">Discounted Amount (<?php echo $coupons ;?>)% </td>
												<td>
													<strong class="grey">
														<span class="currencies">£</span>
														<span class="amount"><?php echo $discountAmount;?></span>
													</strong>
												</td>
											</tr>
                                           <?php }
											?>
											<tr class="shipping">
												<td>Shipping and Handling</td>
												<td>
													Free Shipping
												</td>
											</tr>
											<tr class="order-total">
												<td class="grey">Order Total</td>
												<td>
													<strong class="grey">
														<span class="currencies">£</span>
														<span class="amount"><?php echo $totals;?></span>
													</strong>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>

							<div class="row">
								<div class="col-sm-6">
									<form method="post">
									<div class="coupon with_padding with_border color_border">
										<h3 class="topmargin_0">Discount Codes</h3>
										<p>Enter coupon code if you have one</p>
										<div class="form-group">
											<label class="sr-only" for="coupon_code">Coupon:</label>
											<input type="text" name="coupon_code" class="form-control" id="coupon_code" value="" placeholder="Coupon code">
										</div>
										<!-- <a class="theme_button color1" href="#">Apply Coupon</a> -->
                                        <input type="submit" name="coupon" value="Apply Coupon" class="theme_button color1">

									</div></form>
								</div>
								<div class="col-sm-6">
									<form method="post">
									<div class="shipping-calculator-form with_padding with_border color_border">
										<h3 class="topmargin_0">Shipping &amp; Tax</h3>
										<p>Enter destination to get shipping</p>
										<div class="form-group">
											<select name="shipping_country" id="calc_shipping_country" class="country_to_state form-control">
												<option value="">Select a country…</option>
												<option value="UK" selected="selected"><strong>United Kingdom (UK)</strong></option>
												<optgroup label="Europe">
													<?php
                                                     $sqls="select *from country where continent='Europe'";
                                                     $runs=mysqli_query($obj,$sqls);
                                                     while ($data=mysqli_fetch_array($runs)) {
                                                     	
													 ?>
											<option value="<?php echo $data['country']; ?>"><?php echo $data['country']; ?></option>
												
											<?php }?>
											</optgroup>

												<option value="Row" ><strong>Rest Of the World</strong></option>

											</select>
										</div>
										<div class="form-group">
											<input type="text" class="form-control" value="" placeholder="State / county" name="shipping_state" >
										</div>
										<div class="form-group">
											<input type="text" class="form-control" value="" placeholder="Postcode / Zip" name="shipping_postcode" >
										</div>
										<div>
											<input type="submit" name="shipping" class="theme_button color2" value="Update Totals">
										</div>
									</div></form>
								</div>

							</div>

						</div>
						<!--eof .col-sm-8 (main content)-->

						
					</div>
				</div>
			</section>

			<?php include('includes/footer.php')?>

</body>

</html>

