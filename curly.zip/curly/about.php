<!DOCTYPE html>
<html class="no-js">
<head>
<?php include('includes/head.php');?>
<?php include('include/config.php');?>
</head>

<body>
	
	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->

			<?php include('includes/header.php');?>


			<section class="page_breadcrumbs ds parallax section_padding_top_50 section_padding_bottom_50">
        <?php

        $query="select *from about_banner where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>          
			<img src="images/<?php echo $data['image']; ?>">
                
        <?php } ?>        
			</section>
			
			<div class="using-border">
              <ol class="breadcrumb darklinks">
								<li><a href="./">Home</a>
								</li><li class="active">About</li>
							</ol>
		</div>
			
			
			<section class="ls section_padding_top_100 section_padding_bottom_100 columns_margin_bottom_30 columns_padding_25 table_section table_section_md">
				<div class="container">
					<div class="row">
						<div class="col-md-8">
                 <?php

        $query="select *from about_cat where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>               
							<h2 class="section_header highlight">
								<?php echo $data['large']; ?> <span><?php echo $data['small']; ?></span>
							</h2>
            
                        
                            
							<p class="fontsize_18"><?php echo $data['description']; ?></p>
						</div>
						
						<div class="col-md-4 about1">
                            <img src="images/<?php echo $data['image']; ?>">
						</div>
						<?php } ?>
					</div>
				</div>
			</section>
			
			
			<section class="ls section_padding_top_100 section_padding_bottom_100 instagram">
				<div class="container-fluid">
					<div class="row columns_padding_25 columns_margin_bottom_20">
                         <?php

        $query="select *from about_sub_cat where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>         
						<div class="col-md-6">
							<img src="images/<?php echo $data['image']; ?>">
						</div>
						<div class="col-md-6 instagrambox1">
							<h2 class="section_header highlight" style="color:#fff">
								<?php echo $data['large']; ?> <span><?php echo $data['small']; ?></span>
							</h2>
							<p><?php echo $data['description']; ?></p>
							</div>
                        <?php } ?>
					</div>
					
				</div>
			</section>
			
			
			<section class="ls stats-count">

      <div class="container">
          <?php

        $query="select *from vision where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>      
	  <h2 class="section_header highlight" style="margin-bottom:0px;">
								<?php echo $data['large']; ?> <span><?php echo $data['small']; ?></span>
							</h2>
             
<div class="row text-center">
<p style="width: 100%;"><?php echo $data['description']; ?></p>
    
       <?php } ?>
          
        </div>

      </div>

    </section>
			
			
			<section id="newsletter" class="section-newsletter-area">
        <div class="newsletter-area section-padding">
            <div class="container">
                <div class="row">
                    <!-- start newsletter inner -->
                    <div class="inner-newsletter">
                        <div class="col-md-9 newsbox">
                            <!--start newsletter title -->
                            <div class="newsletter-title">
                                <h2 class="signup"><span>HANDMADE PRODUCTS </span> FOR SPECIAL KIND TO YOUR HAIR.</h2>
                                </div>
                            <!-- end newsletter title -->
                        </div>
                        <div class="col-md-3 newsbox">
                            <!-- start signup form -->
                            <div class="signup-form">
                               <a href="shop.php" target="_blank">Shop Now!Pay Later</a>
                            </div>
                            <!--end signup form -->
                        </div>
                    </div>
                    <!-- end newsletter inner -->
                </div>
            </div>
        </div>
    </section>

			

			<?php include('includes/footer.php')?>

</body>
</html>