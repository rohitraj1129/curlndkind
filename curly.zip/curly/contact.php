<!DOCTYPE html>
<html class="no-js">
<head>
<?php include('includes/head.php');?>
<?php include('include/config.php');?>     
</head>

<body>
	
	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->
			<?php include('includes/header.php');?>
			
           <section class="page_breadcrumbs ds parallax section_padding_top_50 section_padding_bottom_50">
        <?php

        $query="select *from contact_banner where status=1";
        $run= mysqli_query($obj, $query);
        while ($data=mysqli_fetch_array($run)) { 
            $id=$data['id'];

?>          
			<img src="images/<?php echo $data['image']; ?>">
                
        <?php } ?>        
			</section>
			
			<div class="using-border">
              <ol class="breadcrumb darklinks">
								<li><a href="./">Home</a>
								</li><li class="active">Contact</li>
							</ol>
		</div>


			

			<section class="ls columns_padding_25 section_padding_top_75 section_padding_bottom_100">
				<div class="container">
					<div class="row">
                    <h2 class="section_header highlight">
								ASK US<span> A QUESTION</span>
							</h2>
						<div class="col-md-8 to_animate" data-animation="scaleAppear">

							<h3>Contact Form</h3>

							<form class="contact-form row columns_padding_10" method="post" action="http://webdesign-finder.com/html/starford/">
								<div class="col-sm-6">
									<div class="contact-form-name">
										<label for="name">Full Name
											<span class="required">*</span>
										</label>
										<input type="text" aria-required="true" size="30" value="" name="name" id="name" class="form-control" placeholder="Name">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="contact-form-subject">
										<label for="subject">Product
											<span class="required">*</span>
										</label>
										<input type="text" aria-required="true" size="30" value="" name="subject" id="subject" class="form-control" placeholder="Subject">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="contact-form-phone">
										<label for="phone">Phone
											<span class="required">*</span>
										</label>
										<input type="text" aria-required="true" size="30" value="" name="phone" id="phone" class="form-control" placeholder="Phone Number">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="contact-form-email">
										<label for="email">Email address
											<span class="required">*</span>
										</label>
										<input type="email" aria-required="true" size="30" value="" name="email" id="email" class="form-control" placeholder="Email Address">
									</div>
								</div>
								<div class="col-sm-12">

									<div class="contact-form-message">
										<label for="message">Message</label>
										<textarea aria-required="true" rows="5" cols="45" name="message" id="message" class="form-control" placeholder="Message..."></textarea>
									</div>
								</div>

								<div class="col-sm-12">

									<div class="contact-form-submit topmargin_10">
										<button type="submit" id="contact_form_submit" name="contact_submit" class="theme_button color2 wide_button">Send now!</button>
									</div>
								</div>


							</form>
						</div>
						<!--.col-* -->

						<div class="col-md-4 to_animate contactbox" data-animation="scaleAppear">

							<h3>Contact Info</h3>

							
							<p>
					<i class="fa fa-envelope fontsize_18 highlight2 rightpadding_10" aria-hidden="true"></i> curlyandkind@gmail.com
				</p>
				
							<p class="greylinks">
					<i class="fa fa-internet-explorer fontsize_18 highlight2 rightpadding_10" aria-hidden="true"></i> <a href="#0">www.curlyandkind.com</a>
				</p>

						</div>
						<!--.col-* -->

					</div>
					<!--.row -->

				</div>
				<!--.container -->

			</section>

			<?php include('includes/footer.php')?>
			
			</body>
</html>