<?php
 ob_start();

 @session_start();

 error_reporting(1);


$servername = "localhost";

$username = "kumarraj_curly";

$password = "BR{#TWYoe(1^";

$dbname = "kumarraj_curly";

/*$servername = "localhost";

$username = "root";

$password = "";

$dbname = "ids_new";*/

$obj = new mysqli($servername, $username, $password,$dbname) or die(mysqli_error());;


// Check connection

if ($obj->connect_error) {

    die("Connection failed: " . $obj->connect_error);

}


 define(SITE_URL,"localhost");

define(SITE_TITLE,"Curly And Kind");

require_once("variable.php");

?>
