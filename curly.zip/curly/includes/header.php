<?php

if(isset($_GET['action'])){

	if ($_GET['action'] == "delete") {
		
		foreach ($_SESSION['shopping_cart'] as $keys => $values) {
			if ($values['item_id'] == $_GET['id']) {
			 unset($_SESSION['shopping_cart'][$keys]);
			 echo'<script>alert("Item Removed")</script>';
			 echo'<script>window.location="cart.php"</script>';
			}
		}
	}
}


?>
<header class="page_header header_white toggler_xs_right">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-12 display_table">
							<div class="header_left_logo display_table_cell">
								<a href="./" class="logo top_logo">
									<img src="images/logo.png" alt="">
								</a>
							</div>

							<div class="header_mainmenu display_table_cell text-center">
								<!-- main nav start -->
								<nav class="mainmenu_wrapper">
									<ul class="mainmenu nav sf-menu">
										<li class="<?php if(basename($_SERVER['SCRIPT_NAME'])=='index.php'){ ?>active<?php } ?>"><a href="./">Home</a></li>
                                        <!--<li class="<?php if(basename($_SERVER['SCRIPT_NAME'])=='about.php'){ ?>active<?php } ?>"><a href="about.php">About</a></li>-->
										<li class="<?php if(basename($_SERVER['SCRIPT_NAME'])=='shop.php'){ ?>active<?php } ?>"><a href="shop.php">Shop</a></li>
										<li class="<?php if(basename($_SERVER['SCRIPT_NAME'])=='reviews.php'){ ?>active<?php } ?>"><a href="reviews.php">Reviews</a></li>
										<li class="<?php if(basename($_SERVER['SCRIPT_NAME'])=='faq.php'){ ?>active<?php } ?>"><a href="faq.php">FAQ</a></li>
										<li class="<?php if(basename($_SERVER['SCRIPT_NAME'])=='contact.php'){ ?>active<?php } ?>"><a href="contact.php">Contact</a></li>
										<li>

											<?php

                                  if(isset($_SESSION["shopping_cart"])){
	                                $itemarray_id = array_column($_SESSION['shopping_cart'], "item_id");
	                              if(!in_array($id, $itemarray_id))
	                              {
		                              $count = count($_SESSION['shopping_cart']);
		                          }

	
                                  }


											 ?>
									<div class="dropdown cart-dropdown">
										<a href="#" id="topline-cart" data-target="#" data-toggle="dropdown" title="View your shopping cart" class="cart-contents small-text header-button">
											<i class="fa fa-shopping-basket" aria-hidden="true"></i>
											<span class="count header-dropdown-number"><?php echo $count ;?></span>
										</a>
										<div class="dropdown-menu widget_shopping_cart" aria-labelledby="topline-cart">


											<div class="widget_shopping_cart_content">

												<ul class="cart_list product_list_widget ">
												<?php 
                                                 if (isset($_SESSION['shopping_cart'])) {
                                                 	$totals = 0;
                                                 foreach ($_SESSION['shopping_cart'] as $keyss => $valuess) {
													# code...
												
												?>
													<li class="media">
														<div class="media-left media-middle">
															<a href="shop-product-right.html">
																<img src="<?php echo $valuess['item_image']; ?>" class="muted_background" alt="">
															</a>
														</div>

														<div class="media-body">
															<h4>
																<a href="#"><?php echo $valuess['item_name']; ?></a>
															</h4>
															<span class="product-quantity">
																<span><?php echo $valuess['item_qty']; ?> ×</span>
																<span class="amount">£<?php echo $valuess['item_price']; ?></span>
															</span>
															<!-- <a href="#" class="remove" title="Remove this item"></a> -->
														</div>

                             
													</li>
													<?php
                                         $totals = $totals + ($valuess['item_qty'] * $valuess['item_price']);
										?>
													<?php }}?>
												</ul>

												<p class="total content-justify topmargin_10 bottommargin_30">
                                        <span>Total:</span>
                                        <span class="amount oswald">£<?php echo $totals ;?></span>
                                        
                                    </p>

												<p class="buttons content-justify">
                                        <a href="cart.php" class="theme_button color1 inverse">View cart</a>
                                        <a href="checkout.php" class="theme_button color1">Checkout</a>
                                    </p>

											</div>

										</div>
									</div>
								</li>
										</ul>
								</nav>
								<!-- eof main nav -->
								<!-- header toggler -->
								<span class="toggle_menu">
									<span></span>
								</span>
							</div>

						</div>
					</div>
				</div>
			</header>