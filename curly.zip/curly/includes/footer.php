<footer class="page_footer cs section_padding_top_40 section_padding_bottom_20 table_section">
				<div class="container">
					<div class="row">
						<div class="col-md-12 text-center">
							<div class="widget widget_text">
								<a href="./" class="logo vertical_logo">
									<img src="images/logo-footer.png" alt="">
								</a>
								
								<ul class="inline-list big-padding menu menu-style-links topmargin_60">
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-envelope"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-instagram"></i></a>
								</li>
								</ul>
								<p> © 2019 Curly. All Rights Reserved | Design by <a href="http://shadowinfosystem.com/" target="_blank">Shadowinfosystem</a></p>
							</div>
						</div>
						</div>
				</div>
			</footer>

			
		</div>
		<!-- eof #box_wrapper -->
	</div>
	<!-- eof #canvas -->

	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>